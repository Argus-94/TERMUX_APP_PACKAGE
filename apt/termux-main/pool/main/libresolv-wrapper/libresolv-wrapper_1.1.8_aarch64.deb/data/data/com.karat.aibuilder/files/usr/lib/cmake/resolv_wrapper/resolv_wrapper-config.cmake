set(RESOLV_WRAPPER_LIBRARY /data/data/com.karat.aibuilder/files/usr/lib/libresolv_wrapper.so)
